
  function topPets(){
	  var e = document.getElementById("type-Of-Pet");
	  if(e.value == "Cat"){
	  title=e;
	  window.location.href='login.html';
	  }
	  
	  }
  
  function recentUploaded(){
	  var e = document.getElementById("type-Of-Pet");
	  if(e.value == "Cat"){
	  title=e;
	  window.location.href='login.html';
	  }
	  
	  }

